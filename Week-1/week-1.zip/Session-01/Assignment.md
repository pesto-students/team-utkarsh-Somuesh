# Assignment
- What is a protocol stack, and how is it used in web development?
- What are the different types of web servers, and how do they differ in terms of functionality and performance?
- What is web hosting, and what are the different types of hosting services available for websites?
- What is scaling, and why is it important for web applications? How does scaling differ for vertical and horizontal scaling?
- What is SEO (Search Engine Optimization), and how can web developers optimize their websites for better search engine rankings?