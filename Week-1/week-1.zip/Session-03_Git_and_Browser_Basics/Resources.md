## How Browser works:

1. Browser components overview: https://web.dev/howbrowserswork/  
2. Drill down on browser process: https://cabulous.medium.com/how-browser-works-part-i-process-and-thread-f63a9111bae9
3. Mastering chrome dev tools: https://medium.com/hackernoon/mastering-chrome-developer-tools-next-level-front-end-development-techniques-4755649d96ec

## Git
1. Git Cheatsheet: https://www.atlassian.com/git/tutorials/atlassian-git-cheatsheet 
2. Git revision: https://www.freecodecamp.org/news/learn-the-basics-of-git-in-under-10-minutes-da548267cc91/
3. Deploy to github pages1: https://www.freecodecamp.org/news/publish-your-website-netlify-github/
4. Deploy to github pages2: https://dev.to/github/how-to-host-your-first-site-for-free-on-github-pages-45ob
5. [AI]Git codespaces: https://github.com/features/codespaces
6. [AI] Github copilot: https://github.com/features/copilot