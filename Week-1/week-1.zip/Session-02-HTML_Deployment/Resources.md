## HTML Fundamentals
1.	Cheat Sheet: https://websitesetup.org/html5-cheat-sheet/
1.	HTML-CHEAT-SHEET.png : https://websitesetup.org/wp-content/uploads/2019/08/HTML-CHEAT-SHEET.png
2.	Deep Dive Medium Article: https://uxplanet.org/beginners-guide-to-html-and-css-letss-start-off-with-html-3d7ffd035182 
3.	Hands-On: https://developer.mozilla.org/en-US/docs/Web/HTML
1.	HTML : https://html.com/
5. HTML 6 updates: 
https://www.positronx.io/html6-is-coming-here-is-a-sneak-peek/

## Deploying
1.	Cheat Sheet: https://towardsdatascience.com/simple-guide-to-hosting-project-on-github-aebf6f3c6f97 
2.	Deep Dive Medium Article: [Deploying a Website (Static): Your Step into the Internet | by Joe Alongi | Medium  ](https://collectedview.medium.com/deploying-a-website-static-b5583b2963db)
3.	GitHub Pages Hands-On: https://pages.github.com/
4. https://www.codecademy.com/article/f1-u3-github-pages
5. Documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
